<?php 
    class Avalicao{
        public function __construct(
            private float $nota = 0.00
        )
        {}

        public function getNota():float{
            return $this->nota;
        }
    }
?>
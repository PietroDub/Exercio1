<?php 
    class Receita{
        public function __construct(
            public string $nome = "",
            public string $ingredientes = ""
        )
        {}
        
        public function getNome():string{
            return $this->nome;
        }

        public function getIngredientes():string{
            return $this->ingredientes;
        }

    }
?>
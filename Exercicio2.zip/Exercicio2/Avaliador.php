<?php 
    class Avaliador extends Pessoa{
        public string $cpf = "";

        public function __construct($nome, $cpf)
        {
            parent::__construct($nome);
            $this->cpf = $cpf;
        }

        public function getEspecialidade():string{
            return $this->cpf;
        }
    }
?>